from setuptools import setup

setup(
    name="Paquete Calculos",
    version="1.0",
    description="Paquete de Calculos",
    author="Jeison",
    author_email="alarcon_osorio@hotmail.com",
    url="www.engineersystems.com",
    packages=["Calculos", "Calculos.Basicos"]
)