#Video 35 - Paquetes
def multiplicar(op1, op2):
    print("El resultado de la suma es: ", op1 * op2)