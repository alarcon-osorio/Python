# Pildoras Python

>> https://www.youtube.com/watch?v=G2FCfQj-9ig&list=PLU8oAlHdN5BlvPxziopYZRd55pdqFwkeS&index=1&ab_channel=pildorasinformaticas